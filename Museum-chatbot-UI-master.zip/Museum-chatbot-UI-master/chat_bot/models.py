from django.db import models

# Create your models here.

from ckeditor.fields import RichTextField
from django.db.models import IntegerField, ForeignKey, AutoField


class Question(models.Model):

    question = models.TextField(null=False, default=None, blank=False)
    answer = RichTextField(null=False, default=None, blank=False)
    index = AutoField(null=False, default=None, blank=False, unique=True, primary_key=True)
    created_at = models.DateTimeField('date published', auto_now_add=True, blank=True)

    def __str__(self):
        return self.question


class QuestionCorpus(models.Model):
    question = models.TextField(null=False, default=None, blank=False)
    index = ForeignKey(Question, to_field='index', on_delete=models.CASCADE)
    created_at = models.DateTimeField('date published', auto_now_add=True, blank=True)

    def __str__(self):
        return self.question


class Keyword(models.Model):
    word = models.CharField(null=False, blank=False, unique=True, max_length=100)

    def __str__(self):
        return self.word
