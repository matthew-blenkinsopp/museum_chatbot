from datetime import datetime

from django.http import JsonResponse, Http404
from django.shortcuts import render

from .SKChatModel import SKChatModel
from .learning_model import ChatModel
from chat_bot.forms import ChatTextForm


def index(request):
    return render(request, "chatbot/index.html")


def chat(request):
    if request.method == 'POST':
        form = ChatTextForm(request.POST)
        if form.is_valid():
            if form.cleaned_data["sk"]== "1":
                chat = SKChatModel()
                text = form.cleaned_data['text']
                return_text = chat.get_question(text)
                response = {"text": return_text,"sk":True}
            else:
                chat = ChatModel()
                text = form.cleaned_data['text']
                return_text = chat.get_question(text)
                response = {"text": return_text}
            return JsonResponse(response, safe=False)
        else:
            return JsonResponse({'error': "text is required"}, safe=False)
    raise Http404
