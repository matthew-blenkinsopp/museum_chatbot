
let routes = {
    visit:"http://www.aucklandmuseum.com/visit",
    discover:"http://www.aucklandmuseum.com/discover",
    learn:"http://learn.aucklandmuseum.com",
    war:"http://www.aucklandmuseum.com/war-memorial",
    museum:"http://www.aucklandmuseum.com/your-museum",
    contact:"",
    facebook:"https://fb.com",
    youtube:"https://youtube.com",
}

export default routes;