# this has to be run in the django shell

from chat_bot.models import Question, QuestionCorpus, Keyword
import pandas as pd

x = pd.read_csv('~/museum_chat_bot/chat_bot/model_data/FAQs.csv')
for index, row in x.iterrows():
    if index == 126:
        break
    q = Question()
    q.question = row[0]
    q.answer = row[1]
    q.index = index + 1
    q.save()
# Question.objects.filter(question='nan').delete()
# Question.objects.filter(index=160).delete()


y = pd.read_csv('~/museum_chat_bot/chat_bot/model_data/pairedFAQs.csv')
for index, row in y.iterrows():
    qc = QuestionCorpus()
    qc.question = row['questions']
    q = Question.objects.filter(index=row['answers']+1).first()
    qc.index = q
    print(qc.index)
    print(qc.question)
    qc.save()

Keywords = [
        'email', 'speak', 'contact', 'manager', 'contacts', 'contact det', 'who do i', 'who should i', 'right pers',
        'who to', 'who', 'real person', 'image', 'photo', 'get an image', 'track down a photo', 'copy of the portrait',
        'information', 'interest', 'know', 'enquir', 'learn', 'know more', 'learn more', 'eat', 'lunch', 'how long',
        'long',
        'press', 'discount', 'free', 'military', 'service', 'airforce', 'cheap', 'supervis', 'child', 'son', 'daughter',
        'baby', 'parent', 'pray', 'room', 'mosque', 'church', 'oldest', 'How many', 'been photo',
        'have been photographed',
        'founding', 'Museum sell', 'animals', 'treehouse', 'lolly', 'audio-enabled', 'hear', 'impaired', 'deaf', 'guns',
        'swords', 'cool', 'cite', 'object', 'reference', 'taonga', 'back', 'Collections', 'Online', 'scientists',
        'researchers', 'work', 'about the scientists', 'work at Auckland', 'resarcher at the musuem', 'correct',
        'record',
        'error', 'wrong', 'mistake', 'update', 'change', 'changed', 'be changed', 'incorrect', 'inaccurate', 'spelling',
        'collection', 'order', 'copy for', 'get a print', 'article scanned', 'scanned', 'Do you have this image',
        'buy a copy', 'license this image', 'license', 'permission to', 'include this picture', 'digital copy',
        'include your photo', 'scanned copy', 'following image', 'high resolution', 'find', 'out', 'more',
        'find out more about', 'gaining more information', 'CC-BY', 'copyright', 'copyright of', 'choose', 'collect',
        'decide what is worth', 'worth', 'much', 'value', 'any value', 'worth any', 'assess', 'its value',
        'open market',
        'valued', 'kill', 'animal', 'dead', 'bird', 'specimen', 'oldest specimen', 'why', 'specimens', 'important',
        'human',
        'history', 'oldest book', 'paper', 'small', 'community', 'source', 'documents', 'difference', 'library',
        'collected', 'justified', 'colonialism', 'view', 'library collections', 'read online',
        'publication available online', 'heritage', 'join', 'borrow', 'books', 'borrowing object', 'photocopy', 'flag',
        'fly', 'half', 'today', 'event', 'wifi', 'cafe', 'Columbus', 'wheelchair', 'accessibl', 'for wheelchair',
        'Museum accessible', 'reserve', 'book', 'tickets', 'assistants', 'exhibition', 'put', 'put on an exhibition',
        'on an exhibition', 'sponsoring an exhibition', 'sponsoring an exhibition?', 'Shop', 'Library', 'Pou Maumahara',
        'War Memorial space', 'who own', 'owns the museum', 'between the War Memorial Museum and the Auckland Museum',
        'AWMM', 'auckland', 'war', 'name', 'museums in Auckland', 'in Auckland', 'other museum', 'only museum',
        'only museum in Auckland', 'other museums', 'not on display', 'display', 'not on display?', 'i touch',
        'I touch',
        'dark', 'dim', 'no light', 'so dark', 'proper lighting', 'light', 'shops', 'Centennial', '1866', 'Street',
        'Oceans',
        'Coastal', 'galleries', 'Armoury', 'gold', 'culture', 'performance', 'curator', 'items I would like to donate',
        'donat', 'item', 'an item', 'would', 'have', 'donate an item', 'donating items', 'donate item', 'donation of',
        'Would u like them', 'accept the precious small amount of memorabilia', 'love to donate', 'happy to donate',
        'arrange delivery', 'donate them', 'add to its collection', 'Do you accept', 'Would you like this',
        'acquistion',
        'acquir', 'any use to you', 'be of use', 'to offer the', 'hour', 'open', 'museum', 'close', 'fee', 'entry',
        'much is entry', 'cost', 'pay', 'museum free', 'Museum cost', 'cost of the museum', 'How much is the entry',
        'pay to enter', 'Is the museum free', 'museum for free', 'entry fee', 'public', 'transport', 'bus',
        'get to the Museum', 'locat', 'directions', 'park', 'parking', 'prove', ' New Zealand', 'Aucklander',
        'zealand', 'from auckland', 'anniversar', 'commemorate', 'celebrate', 'anzac', 'day', 'lost', 'property',
        'office', 'drink', 'galler', 'bring', 'food', 'food in the galleries', 'drink in the galleries',
        'drinks inside the museum', 'food inside the museum', 'food into the galleries', 'drinks into the galleries',
        'eat inside the museum', 'food and beverage in collections', 'policies concerning food', 'bring in', 'bag',
        'with me', 'keep', 'inside', 'bring my bag', 'leave my bag', 'keep my bag', 'film', 'video', 'take photo',
        'photos', 'take a photo', 'while inside', 'take photos inside', 'photos of the exhibits', 'take videos inside',
        'record inside', 'photos allowed', 'videos while inside', 'videos inside', 'videos of the exhibits',
        'photos of the collections', 'take some photographs', 'take photos in the', 'maori', 'māori', 'portraits',
        'allow',
        'money', 'cash', 'donate to', 'monetary', 'make donat', 'toward', 'donate to the museum', 'money to the museum',
        'donations to the museum', 'donation to the museum', 'donate money', 'donate to the Museum', 'make a donation',
        'vacanc', 'job', 'hir', 'intern', 'work for', 'opportun', 'internship opportunities', 'jobs available',
        'available jobs', 'jobs', 'job vacancies', 'internship', 'internships', 'looking for work', 'career',
        'consider hiring someone', 'positionspositions', 'assistance', 'sell', 'art', 'shop', 'ICOM', 'card', 'roof',
        'Event centre', 'cause', 'charity', 'company', 'birthday', 'anniversary', 'consecrated', 'ground',
        'Wintergardens',
        'volunteer', 'cenotaph', 'mean', 'explain', 'Sir Edmund Hillary', 'Edmund Hillary',
        'items of Sir Edmund Hillarys',
        'items related to Sir Edmund Hillary', 'founded', 'what year', 'creat', 'start', 'history of the museum',
        'Auckland', 'War', 'Memorial', 'when did the museum open', 'What year was the museum', 'museum first open',
        'official opening of the museum', 'opening of the museum', 'museum officially opened', 'Stained', 'glass',
        'ceiling', 'Grand', 'Foyer', 'Trust Board', 'execut', 'team', 'sits on the Trust Board',
        'information about the trust board', 'information about the executive team', 'members of the trust board',
        'executive of the museum', 'executive team of the museum', 'executive team members', 'trust board members',
        'information regarding the trust board', 'Taumata-ā-Iwi', 'maori trust', 'Māori trust', 'Pacific', 'Advisory',
        'Group', 'members', 'Institute', 'apply', 'auckland museum institute', 'audio', 'guides', 'audio guide',
        'research',
        'specialt', 'what kind', 'type of', 'specialist', 'Museum', 'appointment', 'visit', 'visit the lib', 'phd',
        'research about my ancestors', 'Research library', 'research visit', 'doing some research',
        'visit your library',
        'arrange to view', 'private papers', 'to view material', 'come into the library', 'visit the library',
        'Museum Studies', 'information do you have on museums', 'borrow an object', 'borrow objects', 'borrow object',
        'borrowing objectloaning items', 'loaning items', 'exhibition on loan', 'borrow books', 'lend out books',
        'borrow a book', 'lend', 'book avail', 'There is a book', 'items at the library', 'book available',
        'print of a photograph', 'prints of a photograph', 'order images', 'request an image', 'image order',
        'order an image', 'photocopy of this item', 'copy of the original photo', 'copy of the', 'copy of this photo',
        'copy of this', 'high resolution image', 'image orders', 'publications', 'a book I wrote',
        'have new information',
        'i wrote', 'want', 'i have', 'personnel', 'file', 'access', 'family', 'records', 'father',
        'Military Personnel File', 'war record', 'dad', 'service record', 'photographs of family', 'photographs',
        'relative', 'medal', 'receive', 'Cenotaph', 'not', 'help', 'no record', "isn't on", 'Who', 'What record',
        'miss',
        'photograph', 'add', 'birth', 'death', 'appear', 'identify', 'Medal', 'contribute', 'sections'
    ]
for k in Keywords:
    kw = Keyword()
    kw.word = k
    kw.save()
