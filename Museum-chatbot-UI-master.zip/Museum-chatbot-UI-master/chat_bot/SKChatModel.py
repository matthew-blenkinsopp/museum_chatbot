import os

import pandas as pd
from tensorflow.keras.models import load_model
import numpy as np
from sklearn import preprocessing

from chat_bot.models import Question, Keyword


class SKChatModel():

    def getWordCurrentCount(self,i, w):
        try:
            count = self.keywordsDf.loc[i, w]
            if str(count) == 'nan':
                count = 0
        except:
            count = 0

        return count

    def __init__(self):
        self.Keywords = Keyword.objects.all().values_list('word', flat=True)
        self.Keywords = list(dict.fromkeys(self.Keywords))
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        # self.model = load_model(base + '/chat_bot/model_data/bot_model5')
        self.model = load_model(base + '/bot_model11')

        self.originalFAQs = pd.DataFrame(Question.objects.all().values("question", "answer"))

        self.cleanFAQQuestions = self.originalFAQs.iloc[:126, 0].values.tolist()
        self.cleanFAQAnswers = self.originalFAQs.iloc[:126, 1].values.tolist()

        self.keywordsDf = pd.DataFrame(columns=self.Keywords)

        vectorizedData = pd.read_csv(base + '/chat_bot/model_data/keyPhrasesVectorizer.csv')

        y = vectorizedData[['index_id']]

        columnNames = vectorizedData.columns.tolist()
        columnNames.remove('index_id')
        columnNames.remove('question')
        columnNames.remove('created_at')
        columnNames.remove('id')

        self.vectorized_questions = vectorizedData[columnNames]

    def get_question(self, question):
        for word in self.Keywords:
            if str(word).lower() in str(question).lower():

                wordCurrentCount = self.getWordCurrentCount(0, word)
                self.keywordsDf.loc[0, word] = wordCurrentCount + 1

            else:
                self.keywordsDf.loc[0, word] = self.getWordCurrentCount(0, word)

        print('ss', len(self.keywordsDf.columns))
        print('ss', len(self.vectorized_questions.columns))
        for i in self.vectorized_questions.columns:
            if i not in self.keywordsDf.columns:
                print('\n\nC',i,'\n\n\n')
        self.vectorized_questions = self.vectorized_questions.append(self.keywordsDf)

        self.vectorized_questions = np.array(preprocessing.scale(self.vectorized_questions)).tolist()

        predicted = np.argmax(self.model.predict(self.vectorized_questions), axis=-1)

        answerIndex = predicted[-1]

        answer = Question.objects.filter(index=answerIndex).first()
        if answer.answer in ['nan', 'Nan', '', None]:
            return 'No answer available for now for question:' + answer.question + 'please contact <a href="https://www.aucklandmuseum.com/your-museum/contact-us">https://www.aucklandmuseum.com/your-museum/contact-us</a>'

        return answer.answer
