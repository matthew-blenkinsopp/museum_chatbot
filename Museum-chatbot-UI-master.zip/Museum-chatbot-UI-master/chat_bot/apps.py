from django.apps import AppConfig


class ChatBotConfig(AppConfig):
    name = 'chat_bot'
