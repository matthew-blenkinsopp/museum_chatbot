from django.urls import path

from . import views

app_name = 'chat_bot'

urlpatterns = [
    path('', views.index, name="home"),
    path('chat-bot', views.chat, name="chat"),
]
