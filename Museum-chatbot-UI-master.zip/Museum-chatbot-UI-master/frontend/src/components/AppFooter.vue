<template>
    <div class="DynamicFooterApp">
<footer class="text-white">
   <div class="container">
      <div class="flex flex-wrap justify-between">
         <div class="w-full md:w-2/12 col">
            <h3 class="">Contact</h3>
            <a href="https://www.google.com/maps/place/Auckland+War+Memorial+Museum/@-36.8603795,174.7756335,17z/data=!3m1!4b1!4m5!3m4!1s0x6d0d480b4bfd8503:0xb879d9072a5a83c0!8m2!3d-36.8603838!4d174.7778222" target="_blank" class="footer-link">The Auckland Domain Parnell, Auckland New Zealand</a><a href="mailto:info@aucklandmuseum.com" class="am-footer__email">info@aucklandmuseum.com</a><a href="tel:+ 64 9 309 0443" class="am-footer__phone">+ 64 9 309 0443</a><a href="https://www.aucklandmuseum.com/your-museum/contact-us" target="_self" class="footer-link">Find more info at Contact Us</a>
         </div>
         <div class="w-full md:w-1/12 col">
            <h3 class="">Visit</h3>
            <a href="https://www.aucklandmuseum.com/visit/plan-your-visit" target="_self" class="footer-link">Plan your visit</a><a href="https://www.aucklandmuseum.com/visit/whats-on" target="_self" class="footer-link">What´s on</a><a href="https://www.aucklandmuseum.com/visit/exhibitions" target="_self" class="footer-link">Exhibitions</a><a href="https://www.aucklandmuseum.com/visit/galleries" target="_self" class="footer-link">Galleries</a><a href="https://store.aucklandmuseum.com/" target="_self" class="footer-link">Museum store</a><a href="https://www.aucklandmuseum.com/visit/kids-and-family" target="_self" class="footer-link">Kids and family</a><a href="https://www.aucklandmuseum.com/your-museum/venue-hire" target="_self" class="footer-link">Venues</a>
         </div>
         <div class="w-full md:w-1/12 col">
            <h3 class="">Discover</h3>
            <a href="https://www.aucklandmuseum.com/discover/stories" target="_self" class="footer-link">Stories</a><a href="https://www.aucklandmuseum.com/discover/research" target="_self" class="footer-link">Research</a><a href="https://www.aucklandmuseum.com/discover/collections" target="_self" class="footer-link">Collections Online</a><a href="https://www.aucklandmuseum.com/discover/library" target="_self" class="footer-link">Library</a><a href="https://learn.aucklandmuseum.com/" target="_self" class="footer-link">Education</a><a href="https://www.aucklandmuseum.com/discover/collections/our-data" target="_self" class="footer-link">Our data</a>
         </div>
         <div class="w-full md:w-2/12 col">
            <h3 class="">Learn</h3>
            <a href="https://learn.aucklandmuseum.com/" target="_self" class="footer-link">School programmes</a><a href="https://form.jotform.co/83161312567858" target="_self" class="footer-link">Booking enquiry </a><a href="https://learn.aucklandmuseum.com/page/plan-a-visit" target="_self" class="footer-link">Plan a class visit </a><a href="https://learn.aucklandmuseum.com/resources" target="_self" class="footer-link">Educational resources </a>
         </div>
         <div class="w-full md:w-2/12 col">
            <h3 class="">War Memorial</h3>
            <a href="https://www.aucklandmuseum.com/war-memorial/online-cenotaph" target="_self" class="footer-link">Online Cenotaph</a><a href="https://www.aucklandmuseum.com/war-memorial/galleries" target="_self" class="footer-link">War Memorial galleries</a><a href="https://www.aucklandmuseum.com/visit/whats-on/war-memorial" target="_self" class="footer-link">Memorial events and exhibitions</a>
         </div>
         <div class="w-full md:w-2/12 col">
            <h3 class="">Your Museum</h3>
            <a href="http://www.aucklandmuseum.com/your-museum/support-your-museum" target="_self" class="footer-link">Support your museum</a><a href="http://www.aucklandmuseum.com/your-museum/about" target="_self" class="footer-link">About</a><a href="http://www.aucklandmuseum.com/your-museum/get-involved" target="_self" class="footer-link">Get involved</a><a href="https://www.aucklandmuseum.com/your-museum/venue-hire" target="_self" class="footer-link">Venue hire</a><a href="https://www.aucklandmuseum.com/media" target="_self" class="footer-link">Media</a><a href="https://careers.aucklandmuseum.com/" target="_self" class="footer-link">Work at Auckland Museum</a>
         </div>
         <div class="w-full md:w-2/12 col">
            <h3 class="">Plan your cultural journey	</h3>
            <a href="https://www.museumsofauckland.com/" target="_blank" class="footer-link">Visit Auckland´s most loved cultural attractions, events, and galleries that explore our diverse history</a>
            <a href="https://www.museumsofauckland.com/" target="_blank" >
                <img src="https://www.aucklandmuseum.com/getattachment/modular/menus/footer/partners/auckland-stardome-(1)/Museums-of-Auckland-Logo_1.png?lang=en-NZ&amp;width=300&amp;height=143&amp;ext=.png" class="responsive" alt="">
            </a>
            <a href="https://www.aucklandcouncil.govt.nz/" target="_blank">
                <img src="https://www.aucklandmuseum.com/Client/IMG/Modular/partners/auckland-council.png" class="responsive" alt="">
            </a>
         </div>
      </div>
      <div class="social">
          <a href="https://www.facebook.com/AucklandMuseum"  class="fa fa-facebook fa-2x"></a>
          <a href="https://twitter.com/aucklandmuseum/"  class="fa fa-twitter fa-2x"></a>
          <a href="https://instagram.com/aucklandmuseum/"  class="fa fa-instagram fa-2x"></a>
          <a href="http://pinterest.com/aucklandmuseum/"  class="fa fa-pinterest fa-2x"></a>
          <a href="http://www.youtube.com/aucklandmuseum"  class="fa fa-youtube fa-2x"></a>
          <a href="http://www.tripadvisor.com/Attraction_Review-g255106-d257273-Reviews-Auckland_Museum-Auckland_Central_North_Island.html"  class="fa fa-tripadvisor fa-2x"></a>
          <a href="http://www.linkedin.com/company/79976"  class="fa fa-linkedin fa-2x"></a>
      </div>
      <br>
        <div class="w-full line bg-white"></div>
        <div class="clearfix mt-2">
            <a class="float-left" href="http://www.aucklandmuseum.com/terms-of-use">Terms of us</a>
            <div class="float-right">© Copyright Auckland Museum</div>
        </div>
   </div>
</footer>
    </div>
</template>
<script>
import routes from '../routes';
export default {
    data(){
        return{
            routes:routes,
            generalLinks:[
                {title:"Blog",url:routes.blog},
                {title:"Contact",url:routes.contact}
            ],
            privacyLinks:[
                {title:"Privacy",url:"/privacy"},
                {title:"Copyrights",url:"/copyrights"}
            ],
            socialLinks:[
                {title:"Facebook",url:routes.facebook},
                {title:"YouTube",url:routes.youtube},
            ],
        }
    }
}
</script>
<style scoped>
.line{
    height: 1px;
}
.DynamicFooterApp {
    box-sizing: border-box;
    display: flex;
    flex: 0 1 auto;
    flex-direction: column;
    flex-wrap: nowrap;
    justify-content: center;
    align-items: center;
    background: #000;
    color: #bdbdbd;
    width: 100%;
    padding: 40px 0 0;
    margin-top: 128px;
    border-top: 2px solid #dadada;
    font-size: 12px;
}
a{
    padding: 1px;
    display: block;
    color: #ccc;
    word-wrap: break-word;
    text-decoration: none;
}
a:hover{
    text-decoration: underline;
}
.footer-link{
    display: block;
    margin-top: 15px;
}
.responsive{
    display: block;
    width: 100%;

}
.col{
    border-top:1px solid white;
    margin: 1px;
}
.social a{
    display: inline;
    margin: 2px;
    color: #bdbdbd;
    text-decoration: none;
    background: #333;
    transition-duration: 0.2s;
    padding: 15px;
}
.social{
    margin-bottom: 10px;
    margin-top: 10px;
}
.social a:hover{
    color: black;
    background: white;
}
</style>